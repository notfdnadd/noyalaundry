import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

const posts = [
  {
    cat: 'Fabric Care',
    title: 'How to make your favorite hoodie last a decade',
    read: '4 min read',
    img: 'https://images.unsplash.com/photo-1608673670133-4e2efaa43c44?w=900&q=80',
  },
  {
    cat: 'Stain Removal',
    title: 'A field guide to red wine, kopi susu & matcha',
    read: '6 min read',
    img: 'https://images.unsplash.com/photo-1697561728220-759309707638?w=900&q=80',
  },
  {
    cat: 'Lifestyle',
    title: 'The 20-minute Sunday reset that saves your week',
    read: '5 min read',
    img: 'https://images.unsplash.com/photo-1570724097412-dca3aa07af77?w=900&q=80',
  },
];

const categories = ['Laundry Tips', 'Fabric Care', 'Stain Removal', 'Home Care', 'Lifestyle'];

export function Journal() {
  return (
    <section id="journal" className="py-24 md:py-32" style={{ background: '#fff' }}>
      <div className="max-w-[1400px] mx-auto px-6 md:px-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="inline-block px-3 py-1 rounded-full border border-black/15" style={{ fontFamily: 'Inter', fontSize: 11, letterSpacing: '0.15em' }}>
              ✦ THE JOURNAL
            </div>
            <h2
              className="mt-5"
              style={{
                fontFamily: 'Fraunces, serif',
                fontWeight: 400,
                fontSize: 'clamp(40px, 6vw, 96px)',
                lineHeight: 0.95,
                letterSpacing: '-0.03em',
              }}
            >
              Read on, <span style={{ fontStyle: 'italic', color: '#1351AA' }}>fresh thinker.</span>
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((c, i) => (
              <span
                key={c}
                className="rounded-full px-3 py-1 border border-black/15"
                style={{
                  fontFamily: 'Inter',
                  fontSize: 12,
                  background: i === 0 ? '#0E0E10' : 'transparent',
                  color: i === 0 ? '#fff' : '#0E0E10',
                }}
              >
                {c}
              </span>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {posts.map((p, i) => (
            <motion.a
              key={p.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.6 }}
              whileHover={{ y: -6 }}
              href="#"
              className="group flex flex-col"
            >
              <div className="aspect-[4/5] rounded-3xl overflow-hidden">
                <ImageWithFallback
                  src={p.img}
                  alt={p.title}
                  className="w-full h-full object-cover transition group-hover:scale-105"
                />
              </div>
              <div className="mt-5 flex items-center justify-between text-black/60" style={{ fontFamily: 'Inter', fontSize: 12, letterSpacing: '0.1em' }}>
                <span>{p.cat.toUpperCase()}</span>
                <span>{p.read}</span>
              </div>
              <h3
                className="mt-3 pr-6"
                style={{ fontFamily: 'Fraunces', fontWeight: 500, fontSize: 26, lineHeight: 1.1, letterSpacing: '-0.02em' }}
              >
                {p.title}
              </h3>
              <span
                className="mt-4 inline-flex items-center gap-2 self-start"
                style={{ fontFamily: 'Inter', fontSize: 13, color: '#1351AA' }}
              >
                Read article <ArrowUpRight size={14} />
              </span>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
