
  # Modern Premium Laundry Website

  This is a code bundle for Modern Premium Laundry Website. The original project is available at https://www.figma.com/design/6SxeC7Gwk6bYuVJx3JYgWJ/Modern-Premium-Laundry-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  